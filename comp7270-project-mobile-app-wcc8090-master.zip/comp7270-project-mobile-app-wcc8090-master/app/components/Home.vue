<template>
    <Page @navigatedTo="onNavigatedTo">
        <!-- refresh it when log in  -->
        <ActionBar title="Home3" />

        <StackLayout>
            <BottomNavigation height="2000px">
                <TabStrip>
                    <TabStripItem>
                        <Label text="Home"></Label>
                        <Image src="res://home"></Image>
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Estates"></Label>
                        <Image src="res://browse"></Image>
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Rooms"></Label>
                        <Image src="res://search"></Image>
                    </TabStripItem>
                    <TabStripItem>
                        <Label text="Mine"></Label>
                        <Image src="res://settings"></Image>
                    </TabStripItem>
                </TabStrip>
                <TabContentItem>
                    <ListView for="house in houses" @itemTap="onHouseTap">
                        <v-template>
                            <StackLayout flexDirection="row">
                                <Image :src="house.image_url"
                                    stretch="aspectFill" />
                                <Label :text="house.property_title"
                                    class="t-30" style="width: 100%" />
                                <Label :text="house.house_location"
                                    class="t-12" style="width: 100%" />
                                <Label :text="house.house_rent" class="t-12"
                                    style="width: 100%" />
                            </StackLayout>
                        </v-template>
                    </ListView>
                </TabContentItem>

                <TabContentItem>
                    <ListView for="estate in estates" @itemTap="onEstateTap">
                        <v-template>
                            <StackLayout flexDirection="row">
                                <Label :text="estate.name" class="t-30"
                                    style="width: 100%" />
                            </StackLayout>
                        </v-template>
                    </ListView>

                </TabContentItem>

                <TabContentItem>
                    <ListView for="item in contentArray" @itemTap="onTypeTap">
                        <v-template>
                            <StackLayout flexDirection="row">
                                <Label :text="item.content" class="t-30"
                                    style="width: 100%" />
                            </StackLayout>
                        </v-template>
                    </ListView>
                </TabContentItem>

                <TabContentItem>
                    <StackLayout flexDirection="row">
                        <StackLayout orientation="horizontal">
                            <Image
                                src="http://www.oct-cts.com/images/up_scenery/UploadImage/38238/largeImg/201903240347fffe-604.jpg"
                                width="100" />
                            <StackLayout v-if="!logname" flexDirection="row">
                                <Label text="Welcome Login" class="h2 text-left" />
                            </StackLayout>

                            <StackLayout v-else flexDirection="row">
                                <Label :text="logname" class="h2 text-left" />
                            </StackLayout>

                        </StackLayout>

                        <StackLayout flexDirection="row">
                            <ListView for="item in logContentArray"
                                @itemTap="onLogTap">
                                <v-template>
                                    <StackLayout flexDirection="row">
                                        <Label :text="item.content"
                                            class="t-30"
                                            style="width: 100%" />
                                    </StackLayout>
                                </v-template>
                            </ListView>
                        </StackLayout>
                    </StackLayout>
                </TabContentItem>

            </BottomNavigation>
        </StackLayout>
    </Page>
</template>

<script>
    import HouseDetail from "./HouseDetail";
    import HouseListEstate from "./HouseListEstate";
    import HouseListBedroom from "./HouseListBedroom";
    import LogIn from "./LogIn";
    import MyRentals from "./MyRentals";
    import Vue from "nativescript-vue";

    export default {
        mounted: async function() {
            this.logname = global.username;
            console.log(global.username);

            var response = await fetch(
            "http://cd4232ed.ngrok.io/rental", {
                method: "GET",
                credentials: "same-origin"
            });
            if (response.ok) {
                var data = await response.json();
                this.houses = data;
                console.log("successfully loaded");
            } else {
                this.houses = response.statusText;
            }

           
        },

        methods: {
            onNavigatedTo: function() {
                this.logname = global.username;
            },
            onHouseTap: function(args) {
                console.log("Item with index: " + args.index + " tapped");

                this.$navigateTo(HouseDetail, {
                    transition: {},
                    transitionIOS: {},
                    transitionAndroid: {},
                    props: {
                        selectedHouse: args.item,
                        $delegate: this
                    }
                });
            },

            onEstateTap: function(args) {
                console.log("The Estate " + args.index + " tapped");
                this.$navigateTo(HouseListEstate, {
                    transition: {},
                    transitionIOS: {},
                    transitionAndroid: {},
                    props: {
                        selectedEstate: args.item,
                        $delegate: this
                    }
                });
            },

            onTypeTap: function(args) {
                console.log("The Bedroom " + args.index + " tapped");
                this.$navigateTo(HouseListBedroom, {
                    transition: {},
                    transitionIOS: {},
                    transitionAndroid: {},
                    props: {
                        selectedType: args.item,
                        $delegate: this
                    }
                });
            },

            onLogTap: function(args) {
                if (args.index == 0) {
                    console.log("The Log " + args.index + " tapped");
                    this.$navigateTo(LogIn, {
                        transition: {},
                        transitionIOS: {},
                        transitionAndroid: {},
                        props: {
                            selectedState: args.item,
                            $delegate: this
                        }
                    });
                } else {
                    console.log("The MyRentals " + args.index +
                    " tapped");
                    this.$navigateTo(MyRentals, {
                        transition: {},
                        transitionIOS: {},
                        transitionAndroid: {},
                        props: {
                            selectedRental: args.item,
                            $delegate: this
                        }
                    });
                }
            }
        },



        data() {
            return {
                estate: [ ],
                houses: [],
                logname: "",
                contentArray: [{
                        content: "Bedrooms <= 2",
                        type: "small"
                    },
                    {
                        content: "Bedrooms >= 3",
                        type: "big"
                    }
                ],

                logContentArray: [{
                        content: "Logoff / Login",
                        relate: "log"
                    },
                    {
                        content: "My Rentals",
                        relate: "myRental"
                    }
                ]
            };
        }
    };
</script>

<style scoped>
    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }
</style>