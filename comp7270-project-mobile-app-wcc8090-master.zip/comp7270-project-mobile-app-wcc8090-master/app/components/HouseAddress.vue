<template>
    <Page>
        <WebView
            src="https://leafletapi.mtchoy.now.sh/index.html?lat=22.34&lng=114.18&zoom=17&markerLat=22.341072&markerLng=114.179645&markerTitle=AC%20Hall&locate=true" />
    </Page>
</template>

<script>
    export default {
        data() {
            
            return {
                estates: []
                };
            }
    };
</script>

<style>
</style>