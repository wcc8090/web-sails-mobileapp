<template>
    <Page>
        <ScrollView orientation="vertical">
            <StackLayout orientation="vertical" margin="10" class="form">
                <Image :src="selectedHouse.image_url" height="300"
                    stretch="aspectFill" />

                <Label :text="selectedHouse.property_title" margin="10"
                    class="h2" />
                <Label textWrap="true" class="h3">
                    <FormattedString>
                        <Span text="Estate: " />
                        <Span :text="selectedHouse.house_location" />
                        <Span text=" , " />

                        <Span text="Bedroom: " />
                        <Span :text="selectedHouse.house_bedrooms" />
                    </FormattedString>
                </Label>

                <Label textWrap="true" class="h3">
                    <FormattedString>
                        <Span text="Rent: " />
                        <Span :text="selectedHouse.house_rent" />
                        <Span text=" , " />

                        <Span text="Tenants: " />
                        <Span :text="selectedHouse.house_tenants" />
                        <Span text=" , " />

                        <Span text="Area: " />
                        <Span :text="selectedHouse.house_area" />
                    </FormattedString>
                </Label>

                <!--for visitors -->
                <StackLayout v-if="!logname" orientation="horizontal">

                    <Button text="Address" @tap="onAddressTap"
                        class="btn btn-primary btn-rounded-lg" />

                </StackLayout>
                <!-- for clients who didn't rent the house -->
                <StackLayout v-else-if="logname && relHouses.length === 0"
                    orientation="horizontal">
                    <Button text="Move-in" @tap="onMoveInTap"
                        class="btn btn-secondary btn-lg" />
                    <Button text="Address" @tap="onAddressTap"
                        class="btn btn-primary btn-rounded-lg" />
                </StackLayout>

                <!-- for clients who rented the house -->
                <StackLayout v-else orientation="horizontal">

                    <Button text="Move-out" @tap="onMoveOutTap"
                        class="btn btn-danger btn-rounded-lg" />

                    <Button text="Address" @tap="onAddressTap"
                        class="btn btn-primary btn-rounded-lg" />

                </StackLayout>
            </StackLayout>
        </ScrollView>
    </Page>
</template>

<script>
    import HouseAddress from "./HouseAddress";
    import Vue from "nativescript-vue";

    export default {
        props: ["selectedHouse", "$delegate"],

        mounted: async function() {
            this.logname = global.username;

            var response = await fetch(
                "http://cd4232ed.ngrok.io/rental/myrental ", {
                    method: "GET",
                    credentials: "same-origin"
                });
            if (response.ok) {
                var data = await response.json();
                this.houses = data;
                console.log("successfully login myrental ");
            } else {
                this.houses = response.statusText;
            }

            this.relHouses = this.houses.filter(
                function(p) {
                    console.log( "successfully update the state ");
                    if (p.property_title == this.selectedHouse
                        .property_title) {
                        return p;
                    }
                }.bind(this)
            );

            console.log(this.relHouses);
        },

        methods: {
            async onMoveInTap() {
                console.log("Move in Button was pressed");
                console.log(this.selectedHouse.property_title);
                var result = await confirm({
                    title: "Are you sure?",
                    message: " do you want too move in this appartment?",
                    okButtonText: " Yes",
                    cancelButtonText: "No"
                });
                if (result) {
                    
                    if (
                        this.selectedHouse.livers ==  this.selectedHouse.house_tenants
                    ) {
                        await alert(" house is already Full");
                        console.log("Alert dialog closed.");
                    } else {
                        this.newHouses = this.relHouses.concat(this
                            .selectedHouse);

                        var response = await fetch(
                            "http://cd4232ed.ngrok.io/user/roommaster/add/" +
                            this.selectedHouse.id, {
                                method: "POST",
                                credentials: "same-origin"
                            }
                        );
                        await alert("Move in successfully");
                        console.log("Move in successfully log");
                    }
                }
            },

            async onMoveOutTap() {
                console.log("Move-out Button was pressed");
                var result = await confirm({
                    title: "Are you sure?",
                    message: "do you want to move out  of this appartment?",
                    okButtonText: "Yes",
                    cancelButtonText: "No"
                });

                if (result) {
                    // remove the collection

                    var response = await fetch(
                        "http://cd4232ed.ngrok.io/user/roommaster/remove/" + this.selectedHouse.id, 
                        {
                            method: "POST",
                            credentials: "same-origin"
                        }
                    );
                    await alert("Move out successfully");
                    console.log("Move out successfully log");
                }
            },

            async onAddressTap() {
                console.log("Address Button was pressed");

                this.$navigateTo(HouseAddress);
            }
        },

        data() {
            return {
                logname: "",
                houses: [],
                relHouses: [],
                newHouses: []
            };
        }
    };
</script>

<style>
</style>