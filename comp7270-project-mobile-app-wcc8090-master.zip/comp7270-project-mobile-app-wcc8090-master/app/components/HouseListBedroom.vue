<template>
    <Page>
        <ScrollView orientation="vertical">
            <ListView for="house in relHouses" @itemTap="onHouseTap">
                <v-template>
                    <StackLayout flexDirection="row">
                        <Label :text="house.property_title" class="t-30"
                            style="width: 100%" />
                        <Label :text="house.house_location" class="t-15"
                            style="width: 100%" />
                    </StackLayout>
                </v-template>
            </ListView>
        </ScrollView>


    </Page>
</template>

<script>
    import Vue from "nativescript-vue";
    import HouseDetail from "./HouseDetail";

    export default {
        props: ["selectedType", "$delegate"],

        mounted: async function() {
            var response = await fetch(
            "http://cd4232ed.ngrok.io/rental", {
                method: "GET",
                credentials: "same-origin"
            });
            if (response.ok) {
                var data = await response.json();
                this.houses = data;
                console.log("successfully loaded in House Bedroom list");
            } else {
                this.houses = response.statusText;
            }

            this.relHouses = this.houses.filter(
                function(p) {
                    console.log(
                        "successfully update the Bedroomlist");
                    if (p.house_type == this.selectedType.type) {
                        return p;
                    }
                }.bind(this)
            );
        },

        methods: {
            onHouseTap: function(args) {
                console.log("House with index: " + args.index +
                " tapped");
                this.$navigateTo(HouseDetail, {
                    transition: {},
                    transitionIOS: {},
                    transitionAndroid: {},
                    props: {
                        selectedHouse: args.item,
                        $delegate: this
                    }
                });
            }
        },

        data() {
            return {
                houses: [],
                relHouses: [],
            };
        }
    };
</script>

<style>
</style>