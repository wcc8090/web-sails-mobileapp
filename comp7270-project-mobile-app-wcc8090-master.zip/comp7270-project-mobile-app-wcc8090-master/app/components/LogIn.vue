<template>
    <Page>
        <StackLayout orientation="vertical" margin="10" class="form">
            <TextField v-model="username" hint="username"
                class="input input-border" />

            <TextField v-model="password" hint="password"
                class="input input-border" />

            <Button text="Login" @tap="onButtonTap"
                class="btn btn-primary btn-rounded-lg" />
        </StackLayout>

    </Page>
</template>


<script>
    import MyRentals from "./MyRentals";
    import Home from "./Home";

    const userService = {
        login(user) {
            return Promise.resolve(user);
        }
    };
    export default {
        mounted: async function() {},

        methods: {
            onButtonTap: async function() {
                console.log("The Button tapped");
                var response = await fetch(
                    "http://cd4232ed.ngrok.io/user/login", {
                        method: "POST",
                        credentials: "same-origin",
                        headers: {
                            
                            "content-type": "application/x-www-form-urlencoded"
                        },
                        body: "username=" + encodeURIComponent(this.username) +
                            "&password=" + encodeURIComponent(this.password)
                        
                    });

                if (response.ok) {
                    var data = await response.json();
                    this.clients = data;
                    global.username = this.username;
                    console.log(global.username);
                    console.log("user successfully loaded");
                    console.log(response);
                    this.$navigateBack();
                } else {
                    
                }          
            }
        },

        data() {
            return {
                username: "",
                password: "",
               clients: [],
            };
        }
    };
</script>

<style>
</style>