<template>
    <Label text="see you!" />
</template>

<script>
export default {
    data() {
	    return {
	    };
    }
}
</script>

<style>
</style>
