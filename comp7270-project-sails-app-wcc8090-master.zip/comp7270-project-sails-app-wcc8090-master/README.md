<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
# webproject
=======
# nenew-test
>>>>>>> wyccc
=======
# project-1
>>>>>>> 10/17
=======
# project-1
=======
# webproject
>>>>>>> Initial commit
>>>>>>> Initial commit

a [Sails v1](https://sailsjs.com) application


### Links

+ [Sails framework documentation](https://sailsjs.com/get-started)
+ [Version notes / upgrading](https://sailsjs.com/documentation/upgrading)
+ [Deployment tips](https://sailsjs.com/documentation/concepts/deployment)
+ [Community support options](https://sailsjs.com/support)
+ [Professional / enterprise options](https://sailsjs.com/enterprise)


### Version info

<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
This app was originally generated on Sun Oct 27 2019 09:28:26 GMT+0800 (GMT+08:00) using Sails v1.2.3.
=======
This app was originally generated on Thu Oct 10 2019 19:12:34 GMT+0800 (GMT+08:00) using Sails v1.2.3.
>>>>>>> wyccc
=======
This app was originally generated on Thu Oct 17 2019 15:01:43 GMT+0800 (GMT+08:00) using Sails v1.2.3.
>>>>>>> 10/17
=======
This app was originally generated on Thu Oct 17 2019 15:01:43 GMT+0800 (GMT+08:00) using Sails v1.2.3.
=======
This app was originally generated on Sun Oct 27 2019 09:28:26 GMT+0800 (GMT+08:00) using Sails v1.2.3.
>>>>>>> Initial commit
>>>>>>> Initial commit

<!-- Internally, Sails used [`sails-generate@1.16.13`](https://github.com/balderdashy/sails-generate/tree/v1.16.13/lib/core-generators/new). -->



<!--
Note:  Generators are usually run using the globally-installed `sails` CLI (command-line interface).  This CLI version is _environment-specific_ rather than app-specific, thus over time, as a project's dependencies are upgraded or the project is worked on by different developers on different computers using different versions of Node.js, the Sails dependency in its package.json file may differ from the globally-installed Sails CLI release it was originally generated with.  (Be sure to always check out the relevant [upgrading guides](https://sailsjs.com/upgrading) before upgrading the version of Sails used by your app.  If you're stuck, [get help here](https://sailsjs.com/support).)
-->

=======
my milesstione2 code is in branch test
I also copy a zip to your mail: mtchoy@comp.hkbu.edu.hk.
>>>>>>> ff4ebbad0f98ff15709f0977b3c69a074f22014b
