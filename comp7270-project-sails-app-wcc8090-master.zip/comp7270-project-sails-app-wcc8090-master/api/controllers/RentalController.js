/**
 * RentalController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
    // action - create
    create: async function (req, res) {

        if (req.method == "GET")
            return res.view('rental/create');

        if (!req.body.Rental)
            return res.badRequest("Form-data not received.");

        await Rental.create(req.body.Rental);

        return res.ok("Successfully created!");
    },
    index: async function (req, res) {

        var models = await Rental.find();
        return res.view('rental/index', { rentals: models });

    },
    // action - update
    update: async function (req, res) {

        if (req.method == "GET") {

            var model = await Rental.findOne(req.params.id);

            if (!model) return res.notFound();

            return res.view('rental/update', { rental: model });

        } else {

            if (!req.body.Rental)
                return res.badRequest("Form-data not received.");

            var models = await Rental.update(req.params.id).set({
                porpertytitle: req.body.Rental.porpertytitle,
                imageURL: req.body.Rental.imageURL,
                estate: req.body.Rental.estate,
                bedroom: req.body.Rental.bedroom,
                grossarea: req.body.Rental.grossarea,
                expectedtenants: req.body.Rental.expectedtenants,
                rent: req.body.Rental.rent,
                highlightedProperty: req.body.Rental.highlightedProperty     }).fetch();
        

        if(models.length == 0) return res.notFound();

            return res.ok("Record updated");

        }
    },
    // action - delete 
delete: async function (req, res) {

    if (req.method == "GET") return res.forbidden();

    var models = await Rental.destroy(req.params.id).fetch();

    if (models.length == 0) return res.notFound();

    return res.ok("Rental Deleted.");

},
// action - view
view: async function (req, res) {

    var model = await Rental.findOne(req.params.id);

    if (!model) return res.notFound();

    return res.view('rental/view', { rental: model });

},
home:async function (req,res){
    var model = await Rental.find({
            where:{'box':{'!=':'dummy'}},
            limit:4
        }
    )
        .sort([{id:'DESC'},]);

    console.log("home", model);
    return res.view('rental/home',{rentals:model});
},
search: async function(req, res){
    // req.query.Rental = req.query.Rental || {};
        const qEtate = req.query.estate || "";
        const qBedrooms = parseInt(req.query.bedroom);
        const qminarea = parseInt(req.query.minarea) || 0;
        const qmaxarea = parseInt(req.query.maxarea) || 90000;
        const qminrent = parseInt(req.query.minrent) || 0;
        const qmaxrent = parseInt(req.query.maxrent) || 90000;
        const qPage = Math.ceil(req.query.page - 1, 0) || 0;
        const numOfItemsPerPage = 2;

console.log("qestte", qEtate);

        if (isNaN(qBedrooms)) {
            var numOfPage = Math.ceil(await Rental.count() / numOfItemsPerPage);
            var models = await Rental.find({
                where: {
                    estate:{contains: qEtate},
                    grossarea: {'>=': qminarea ,'<=': qmaxarea},
                    rent: {'>=': qminrent , '<=': qmaxrent}
                },
                limit: numOfItemsPerPage,
                skip: numOfItemsPerPage * qPage,
            });
            console.log(qmaxarea);
            console.log(qminarea);
            console.log(qmaxrent);
            console.log("results", models);

            return res.view('rental/search', { rentals: models, count: numOfPage });
        }
        else {
            var models = await Rental.find({
                where:{
                    estate: {contains: qEtate},
                    bedroom:qBedrooms,
                    grossarea: {'>=': qminarea,'<=': qmaxarea},
                    rent: {'>=': qminrent,'<=': qmaxrent}
                },
                limit: numOfItemsPerPage,
                skip: numOfItemsPerPage * qPage

            });
            var count_number = await Rental.count({
                where:{
                    estate: {contains: qEtate},
                    bedroom:qBedrooms,
                    grossarea: {'>=': qminarea,'<=': qmaxarea},
                    rent: {'>=': qminrent,'<=': qmaxrent}
                }
            });
            console.log(count_number);
            var paginate_num = Math.ceil(count_number / numOfItemsPerPage);
            return res.view('rental/search', { rentals: models, count: paginate_num });

        }
},
populate: async function (req, res) {

    var model = await Rental.findOne(req.params.id).populate("buy");

    if (!model) return res.notFound();

    return res.json(model);

},


myrental:async function (req,res){
        
    var model = await User.findOne({username:req.session.username}).populate("roommaster")

    console.log("myrental", model.roommaster);
    return res.view('rental/myrental',{rentals:model.roommaster});
},

};

