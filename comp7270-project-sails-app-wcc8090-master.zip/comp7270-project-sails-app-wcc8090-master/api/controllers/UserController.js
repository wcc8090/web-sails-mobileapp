/**
 * UserController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
  
    login: async function (req, res) {

        if (req.method == "GET") return res.view('user/login');
    
        if (!req.body.username || !req.body.password) return res.badRequest();
    
        var user = await User.findOne({ username: req.body.username });
    
        if (!user) return res.status(401).send("User not found");
    
        if (user.password != req.body.password) 
            return res.status(401).send("Wrong Password");
    
        req.session.regenerate(function (err) {
    
            if (err) return res.serverError(err);
    
            req.session.username = req.body.username;

            req.session.userid = user.id;
    
            sails.log("[Session] ", req.session);
            
            return res.ok("login succcessfully ");
    
        });    
    },
    
    logout: async function (req, res) {

        req.session.destroy(function (err) {
        
            if (err) return res.serverError(err);
            
            return res.ok("Log out successfully.");
            
        });
    },
    populate: async function (req, res) {

        var model = await User.findOne(req.params.id).populate("roommaster");
    
        if (!model) return res.notFound();
    
        return res.json(model);
    
    },
    add: async function (req, res) {

        if (!await User.findOne(req.session.userid)) return res.notFound();
        
        const thatRental = await Rental.findOne(req.params.fk).populate("buy", {id: req.session.userid});
    
        if (!thatRental) return res.notFound();
            
        if (thatRental.buy.length)
            return res.status(409).send("Already added.");   // conflict
        
        await User.addToCollection(req.session.userid, "roommaster").members(req.params.fk);
    
        return res.ok('Operation completed.');
    
    },
    remove: async function (req, res) {

        if (!await User.findOne(req.session.userid)) return res.notFound();
        
        const thatRental = await Rental.findOne(req.params.fk).populate("buy", {id: req.session.userid});
        
        if (!thatRental) return res.notFound();
    
        if (!thatRental.buy.length)
            return res.status(409).send("Nothing to delete.");    // conflict

        await User.removeFromCollection(req.session.userid, "roommaster").members(req.params.fk);

        return res.ok('Operation completed.');
    
    },
};

