/**
 * Seed Function
 * (sails.config.bootstrap)
 *
 * A function that runs just before your Sails app gets lifted.
 * > Need more flexibility?  You can also create a hook.
 *
 * For more information on seeding your app with fake data, check out:
 * https://sailsjs.com/config/bootstrap
 */

module.exports.bootstrap = async function() {

  // By convention, this is a good place to set up fake data during development.
  //
  // For example:
  // ```
  // // Set up fake development data (or if we already have some, avast)
  // if (await User.count() > 0) {
  //   return;
  // }
  //
  // await User.createEach([
  //   { emailAddress: 'ry@example.com', fullName: 'Ryan Dahl', },
  //   { emailAddress: 'rachael@example.com', fullName: 'Rachael Shaw', },
  //   // etc.
  // ]);
  // ```
  if (await Rental.count() == 0) {

    await Rental.createEach([
      { porpertytitle: "新元朗中心出售", imageURL: "https://i.loli.net/2019/10/27/JNHMerGhWsza2XL.jpg" ,estate:"Tin Ma Court",bedroom:4,grossarea:900,expectedtenants:"1",rent:10000,highlightedProperty:"dummy",createdate:"2019/10/28"},
      { porpertytitle: "慧景軒出售", imageURL: "https://i.loli.net/2019/10/27/gMqTS873bW1kLH4.jpg" ,estate:"Festival City",bedroom:3,grossarea:900,expectedtenants:"100",rent:10000,highlightedProperty:"dummy",createdate:"2019/10/28"},
      { porpertytitle: "新屯門中心出售", imageURL: "https://i.loli.net/2019/10/27/Lc3vHEVNkjuDTxw.jpg" ,estate:"Festival City",bedroom:2,grossarea:900,expectedtenants:"100",rent:10000,highlightedProperty:"dummy",createdate:"2019/10/28"},
      { porpertytitle: "海翠花園出售", imageURL: "https://i.loli.net/2019/10/27/QLE9lXgz8IcdZSj.jpg" ,estate:"Festival City",bedroom:5,grossarea:800,expectedtenants:"104",rent:12000,highlightedProperty:"dummy",createdate:"2019/10/28"},
      // etc.
    ]);

}
if (await User.count() ==0) {
    await User.createEach([
      { username: "admin", password: "123456" },
      { username: "visitor", password: "111111" },
      { username: "wangyuchen", password: "123456" },
      { username: "ouziming", password: "654321" }
      // etc.
    ]);
}

const yuanlang = await Rental.findOne({porpertytitle: "新元朗中心出售"});
const huijin = await Rental.findOne({porpertytitle: "慧景軒出售"});
const tunmen = await Rental.findOne({porpertytitle: "新屯門中心出售"});
const haicui = await Rental.findOne({porpertytitle: "海翠花園出售"});
const admin = await User.findOne({username: "admin"});
const wangyuchen = await User.findOne({username: "wangyuchen"});
const ouziming = await User.findOne({username: "ouziming"})


await User.addToCollection(admin.id, 'roommaster').members([yuanlang.id,huijin.id,tunmen.id,haicui.id]);
await User.addToCollection(wangyuchen.id, 'roommaster').members(yuanlang.id);
await User.addToCollection(ouziming.id, 'roommaster').members(huijin.id);
};



